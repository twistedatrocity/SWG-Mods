#This mod increase the font size and element size for the left pane of:
  - Inventory view
  - Container view (when viewing objects in containers)
  - Examine window

# Increases the font size and row size for list elements in the free resource crates
and various dialogues including structure management and vet reward claim dialogue,
G9 rigger.... etc. Many dialogues now readable on HD screens.

# Increases font size in notes window.

# Increases font size in crafting windows for res details and ingredient lists.

# Contains Elour's elongated list mod.

# Entertainer Image designer redone with new layout and font sizes.

and more.... too much to list.


This mod places files in your game ui folder e.g.  <SWG>/ui/

Restart game after install.


To remove the mod just delete the files from the ui folder and restart game.
