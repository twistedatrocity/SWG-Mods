#This mod increase the font size and element size for the left pane of:
  - Inventory view
  - Container view (when viewing objects in containers)
  - Examine window

# Increases the font size and row size for list elements in the free resource crates
and various dialogues including structure management and vet reward claim dialogue,
G9 rigger.... etc. Many dialogues now readable on HD screens.

# Increases font size in notes window.

# Increases font size in crafting windows for res details and ingredient lists.

# Contains Elour's elongated list mod also.


This mod places 10 files in your game ui folder e.g.  <SWG>/ui/

ui_craft_assembly.inc
ui_craft_customize.inc
ui_craft_draft.inc
ui_craft_experiment.inc
ui_craft_summary.inc
ui_pda_examine.inc
ui_pda_inventory.inc
ui_pda_notepad.inc
ui_scripted.inc
ui_styles.inc


To remove the mod just delete the above files from the ui folder and restart game.
